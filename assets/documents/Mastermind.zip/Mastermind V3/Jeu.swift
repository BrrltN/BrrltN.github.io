//
//  Jeu.swift
//  MastermindV2
//
//  Created by admin on 07/02/2017.
//  Copyright © 2017 NIKORI GUILD. All rights reserved.
//

import UIKit

class Jeu {
    
    /*********************************************/
    /******* DECLARATION DES VARIABLES ***********/
    /*********************************************/
    
    //Instanciation d'un objet Tentative et d'un objet Secret
    let tentative = Tentative()
    let secret = Secret()
    
    //Variables d'historique de tentatives
    var histoTentative:[Any] = []
    var indexTentative:Int = 0
    
    //Variables des combinaisons
    var tabSecret:[Pion] = []
    var tabTentative:[Pion] = []
    
    //Tableaux de vérifications
    var tentativeVerif:[Bool] = []
    var secretVerif:[Bool] = []
    
    //Tableaux de compte
    var bpCount = 0
    var mpCount = 0
    
    //Variable de victoire
    public var win = false
    
    /*********************************************/
    /******* CONSTRUCTEUR ************************/
    /*********************************************/
    init() {
    }
    
    /*********************************************/
    /******* FONCTIONS DE JEU ********************/
    /*********************************************/
    func InitGame(){
        tabSecret = secret.CreateSecret()
    }
    
    func TourDeJeu(i0:Int, i1:Int, i2:Int, i3:Int){
        
        if (histoTentative.count <= 7 && !win){
            Jouer(i0: i0, i1: i1, i2: i2, i3: i3)
            GestionVictoire()
        }
        
    }
    
    func Jouer(i0: Int, i1: Int, i2: Int, i3: Int){
        tentative.SetInput(iu0: i0, iu1: i1, iu2: i2, iu3: i3)
        tabTentative = tentative.CreateTentative()
        tentativeVerif = [tabTentative[0].used, tabTentative[1].used, tabTentative[2].used, tabTentative[3].used]
        secretVerif = [tabSecret[0].used, tabSecret[1].used, tabSecret[2].used, tabSecret[3].used]
        CompareBienPlace()
        CompareMalPlace()
        StoreTentative()
    }
    
    //HISTORIQUE (UNIQUEMENT EN CONSOLE) DU JEU
    func StoreTentative(){
        histoTentative.append([tabTentative[0].colorPicked, bpCount, mpCount])
        print(histoTentative)
    }
    
    func GestionVictoire() -> Bool{
        win = bpCount < 4 ? false : true
        return win
    }
    
    /*********************************************/
    /******* FONCTIONS DE COMPARAISON ************/
    /*********************************************/
    
    // CHERCHE LES BIEN PLACES
    func CompareBienPlace(){
        bpCount = 0
        mpCount = 0
        for i in 0...3 {
            if tabSecret[i].colorPicked == tabTentative[i].colorPicked {
                bpCount += 1
                tentativeVerif[i] = true
                secretVerif[i] = true
            }
        }
    }
    
    //CHERCHE LES MAL PLACES
    func CompareMalPlace(){
        for i in 0...3 {
            if tentativeVerif[i] == false {
                for j in 0...3 {
                    if tabTentative[i].colorPicked == tabSecret[j].colorPicked && secretVerif[j] == false{
                        mpCount += 1
                        secretVerif[j]=true
                    }
                }
            }
        }
    }
}
