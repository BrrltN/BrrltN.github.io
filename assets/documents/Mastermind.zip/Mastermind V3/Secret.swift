//
//  Secret.swift
//  MastermindV2
//
//  Created by admin on 07/02/2017.
//  Copyright © 2017 NIKORI GUILD. All rights reserved.
//

import UIKit

class Secret{
    
    /*********************************************/
    /******* DECLARATION DES VARIABLES ***********/
    /*********************************************/
    var secret:[Pion] = []
    
    init() {
    }
    
    public func CreateSecret() -> [Pion]{
        if(secret.isEmpty){
            for i in 0...3{
                let alea = Int(arc4random_uniform(7)+1)
                secret.append(Pion(col:alea, pos:i)) // Permet d'instancier un pion et de le mettre dans le tableau CombinaisonSecret
                print("============ PION SECRET " + String(i) + " ============")
                print(secret[i].GetColor())
                print(secret[i].GetPosition())
            }
        }
        return secret
    }
    
}
