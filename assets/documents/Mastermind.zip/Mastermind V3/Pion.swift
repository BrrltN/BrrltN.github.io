//
//  Pion.swift
//  MastermindV2
//
//  Created by admin on 07/02/2017.
//  Copyright © 2017 NIKORI GUILD. All rights reserved.
//

import UIKit

class Pion {
    
    /*********************************************/
    /******* DECLARATION DES VARIABLES ***********/
    /*********************************************/
    var colorArray:[UIColor] = [UIColor.white, UIColor.brown, UIColor.blue, UIColor.green, UIColor.yellow, UIColor.orange, UIColor.red, UIColor.purple]//Tableau Valeur Hexadécimale
    var colorPicked:UIColor = UIColor.white
    var position:Int = 4 //Indice de la position du pion dans l'un des tableaux
    var used:Bool = false //Indique Vrai ou Faux pour les tableaux verifTentative[] et verifSecret[]
    
    init(col:Int, pos:Int){
        SetColor(i: col)
        SetPosition(i: pos)
        used = false
    }
    
    //Assesseurs
    //Setteurs
    
    func SetColor(i:Int){ // DEFINIR i AILLEURS DANS LE CODE
        if (i >= 0 && i <= 7){
            colorPicked = colorArray[i]
        }
    }
    
    func SetPosition(i:Int){
        position = i
    }
    
    //Getteurs
    func GetColor() -> UIColor{
        return colorPicked
    }
    
    func GetPosition() -> Int{
        return position
    }
    
    func isUsed() -> Bool{
        return used
    }
    
    
}

