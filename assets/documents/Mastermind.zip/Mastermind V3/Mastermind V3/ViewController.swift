//
//  ViewController.swift
//  MastermindV2
//
//  Created by admin on 07/02/2017.
//  Copyright © 2017 NIKORI GUILD. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    /*********************************************/
    /******* DECLARATION DES VARIABLES ***********/
    /*********************************************/

    // Instanciation des Objets Secret et Jeu
    let jeu = Jeu()
    let tent = Tentative()
    let pion = Pion(col: 8, pos: 8)
    
    // Pion Char
    let pionChar:String = "あ"
    var pionTentative:[UILabel] = []
    var inputUserInt:[Int] = [8,8,8,8]
    
    // Compteurs et Booleens
    var k:Int = 1
    var restartAvailable = false
    
    // Contrôles graphiques
    var label:UILabel = UILabel()
    var bpLabel:UILabel = UILabel()
    var mpLabel:UILabel = UILabel()
    var rond:UILabel = UILabel()
    var restartButton:UIButton = UIButton()
    var messageLabel:UILabel = UILabel()
    
    /*********************************************/
    /******* SWIFT START FUNCS *******************/
    /*********************************************/
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        jeu.InitGame()
        generateTentative()
        viewButtons()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*********************************************/
    /******* GESTION AFFICHAGE *******************/
    /*********************************************/
    
    
    // AFFICHE L'HISTORIQUE DE JEU EN FONCTION DU NB DE TOUR ET DU CAS DE VICTOIRE
    func AfficherHisto(){
        if(k<8){
            //Victoire
            if(jeu.win) {
                k = 8
                generateRestartUI()
                restartAvailable = true
            }
            generateRowUI()
            
        } else if(k==8){
            generateRowUI()
            generateRestartUI()
            restartAvailable = true
        }
        
    }
    
    
    /*********************************************/
    /******* FONCTION GENERATION CONTROLES GRAPH */
    /*********************************************/
    
    //LIGNE DE RESTART
    func generateRestartUI(){
        //Génération du bouton de restart
        let restartButton = UIButton(frame: CGRect(x: 300, y: 540, width: 100, height: 50))
        restartButton.addTarget(self, action: #selector(ViewController.restartGameButton), for: .touchUpInside)
        restartButton.backgroundColor = UIColor.red
        restartButton.setTitle("Rejouer", for: UIControlState.normal)
        restartButton.setTitleColor(UIColor.init(white: 255, alpha: 0.5), for: .highlighted)
        restartButton.titleLabel?.textColor = UIColor.white
        
        
        //Génération du message de victoire
        let messageLabel = UILabel(frame: CGRect(x: 25, y: 530, width: 300, height: 70))
        messageLabel.textColor = UIColor.white
        messageLabel.text = jeu.win ? "Bravo !" : "C'est la défaite !"
        messageLabel.font = UIFont(name: messageLabel.font.fontName, size: 30)
        
        //Ajout à la vue
        self.view.addSubview(restartButton)
        self.view.addSubview(messageLabel)
        
        if(restartAvailable) {
            
        }
        
    }
    
    //LIGNE DE JEU DANS L'HISTORIQUE
    func generateRowUI(){
        label = UILabel(frame: CGRect(x: 0, y: 32+55*k, width: 420 , height: 55))
        bpLabel = UILabel(frame: CGRect(x: 320, y: 32+55*k, width: 80, height: 55))
        mpLabel = UILabel(frame: CGRect(x: 380, y: 32+55*k, width: 80, height: 55))
        
        // Changement du background de la ligne.
        label.backgroundColor = k%2==0 ? UIColor.init(white: 255, alpha: 0) : UIColor.init(white: 0, alpha: 0.2)
        
        
        //Modification des labels bp et mp
        bpLabel.text = String(jeu.bpCount)
        bpLabel.textColor = UIColor.white
        mpLabel.textColor = UIColor.white
        mpLabel.text = String(jeu.mpCount)
        
        self.view.addSubview(label)
        
        // Boucle pour générer les 4 caractères
        for i in 0...3{
            rond = UILabel(frame: CGRect(x: 25+70*i, y: 20+55*k, width: 80, height:80))
            rond.text = pionChar
            rond.font = UIFont(name: label.font.fontName, size: 30)
            rond.textColor = jeu.tabTentative[i].colorPicked
            self.view.addSubview(rond)
        }
        
        self.view.addSubview(bpLabel)
        self.view.addSubview(mpLabel)
        
        // Increment du compteur k
        k += 1
    }
    
    //LIGNE DES INPUTS DE TENTATIVE
    func generateTentative(){
        for i in 0...3 {
            pionTentative.append(UILabel(frame: CGRect(x: 25+70*i, y: 585, width: 80, height:80)))
            pionTentative[i].text = pionChar
            pionTentative[i].textColor = UIColor.lightGray
            pionTentative[i].font = UIFont(name: pionTentative[i].font.fontName, size: 30)
            self.view.addSubview(pionTentative[i])
        }
    }
    
    // LIGNES DES BOUTONS DE COULEUR
    func viewButtons() {
        var button:[UIButton] = []
        var inputUser:[UITextField] = []
        for i in 0...7 {
            if i <= 3 {
                button.append(UIButton(frame: CGRect(x: 40+60*i, y: 650, width: 35, height: 35)))
            } else {
                button.append(UIButton(frame: CGRect(x: 40+60*(i-4), y: 690, width: 35, height: 35)))
            }
            
            button[i].backgroundColor = pion.colorArray[i]
            button[i].addTarget(self, action: #selector(ViewController.colorPick), for: .touchUpInside)
            button[i].tag = i
            self.view.addSubview(button[i])
        }
        for j in 0...3 {
            inputUser.append(UITextField(frame: CGRect(x: 30*j, y:700, width: 30, height: 30)))
            inputUser[j].isHidden = true
            self.view.addSubview(inputUser[j])
        }
    }
    
    /*********************************************/
    /******* CLEAR SCREEN ************************/
    /*********************************************/
    
    func clearScreen(){
        if(restartAvailable){
            rond.removeFromSuperview()
            restartAvailable = false
        }
    }
    
    /*********************************************/
    /******* BUTTONS FUNC ************************/
    /*********************************************/
    
    // COLORS BUTTON
    @IBAction func colorPick(_ sender: AnyObject?) {
        for h in 0...3 {
            if (pionTentative[h].textColor == UIColor.lightGray){
                pionTentative[h].textColor = sender?.backgroundColor
                inputUserInt[h] = (sender?.tag)!
                break
            }
        }
        
    }
    
    // RESET BUTTON
    @IBAction func resetTentative(_ sender: Any) {
        for i in 0...3 {
            pionTentative[i].textColor = UIColor.lightGray
            inputUserInt[i] = 8
        }
    }
    
    // RESTART GAME BUTTON
    @IBAction func restartGameButton(_ sender: Any) {
        jeu.tabSecret = []
        jeu.InitGame()
        jeu.bpCount = 0
        jeu.mpCount = 0
        jeu.histoTentative = []
        jeu.win = false
        k = 1
    }
    
    // VALIDATE BUTTON
    @IBAction func compare(_ sender: Any) {
        //Lancer un tour de jeu
        jeu.TourDeJeu(i0: inputUserInt[0] ,i1: inputUserInt[1], i2: inputUserInt[2], i3: inputUserInt[3])
        // Afficher la ligne actuelle dans l'historique
        AfficherHisto()
        // Reset de la ligne de tentative
        for i in 0...3 {
            pionTentative[i].textColor = UIColor.lightGray
            inputUserInt[i] = 8
        }
    }

    
}
