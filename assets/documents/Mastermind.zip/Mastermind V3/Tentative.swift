//
//  Tentative.swift
//  MastermindV2
//
//  Created by admin on 07/02/2017.
//  Copyright © 2017 NIKORI GUILD. All rights reserved.
//

import UIKit

class Tentative {
    
    /*********************************************/
    /******* DECLARATION DES VARIABLES ***********/
    /*********************************************/
    var inputArray:[Int] = []
    var tentative:[Pion] = []
    
    
    init(){
    }
    
    
    func SetInput(iu0:Int, iu1:Int, iu2:Int, iu3:Int){
        if(iu0 != nil && iu1 != nil && iu2 != nil && iu3 != nil){
            let iuArray = [iu0, iu1, iu2, iu3]
            inputArray = []
            for i in 0...3 {
                inputArray.append(iuArray[i])
            }
            print(inputArray)
        } else { inputArray = [7,7,7,7] }
        
    }
    
    func GetInput() -> [Int]{
        return inputArray
    }
    
    func CreateTentative() -> [Pion]{
        let colorInput = GetInput()
        tentative=[]
        for i in 0...3{
            tentative.append(Pion(col:colorInput[i], pos:i))
        }
        return tentative
    }
    
    
}

